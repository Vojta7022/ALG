#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef unsigned short Cell; // enough for up to 40000 cells

struct Segment
{
    Cell start;
    Cell end;
    int w;    // number of valves on this segment
    char dir; // 0 = horizontal, 1 = vertical
};

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int M, N;
    if (!(cin >> M >> N))
    {
        return 0;
    }

    // Read input grid
    vector<vector<int>> a(M, vector<int>(N));
    for (int i = 0; i < M; ++i)
    {
        for (int j = 0; j < N; ++j)
        {
            cin >> a[i][j];
        }
    }

    // Compute row-wise prefix sums
    vector<vector<int>> rowPref(M, vector<int>(N));
    for (int i = 0; i < M; ++i)
    {
        int sum = 0;
        for (int j = 0; j < N; ++j)
        {
            sum += a[i][j];
            rowPref[i][j] = sum;
        }
    }

    // Compute column-wise prefix sums
    vector<vector<int>> colPref(M, vector<int>(N));
    for (int j = 0; j < N; ++j)
    {
        int sum = 0;
        for (int i = 0; i < M; ++i)
        {
            sum += a[i][j];
            colPref[i][j] = sum;
        }
    }

    int cells = M * N;
    Cell startCell = 0; // (0,0) -> 0 * N + 0
    Cell destCell = (Cell)((M - 1) * N + (N - 1));

    // Reserve approximate number of segments to avoid reallocations
    // Horizontal segments: for each row, choose (c1, c2), c1 < c2
    // Count = M * N*(N-1)/2
    // Vertical segments: N * M*(M-1)/2
    long long horizCount = 1LL * M * N * (N - 1) / 2;
    long long vertCount = 1LL * N * M * (M - 1) / 2;
    vector<Segment> segments;
    segments.reserve((size_t)(horizCount + vertCount));

    // Generate all horizontal segments (to the east)
    for (int i = 0; i < M; ++i)
    {
        for (int c1 = 0; c1 < N - 1; ++c1)
        {
            for (int c2 = c1 + 1; c2 < N; ++c2)
            {
                int innerSum = 0;
                if (c2 >= c1 + 2)
                {
                    // sum of a[i][c1+1..c2-1]
                    int rightIndex = c2 - 1;
                    int leftIndex = c1;
                    innerSum = rowPref[i][rightIndex] - rowPref[i][leftIndex];
                }
                Cell start = (Cell)(i * N + c1);
                Cell end = (Cell)(i * N + c2);
                Segment s;
                s.start = start;
                s.end = end;
                s.w = innerSum;
                s.dir = 0; // horizontal
                segments.push_back(s);
            }
        }
    }

    // Generate all vertical segments (to the south)
    for (int j = 0; j < N; ++j)
    {
        for (int r1 = 0; r1 < M - 1; ++r1)
        {
            for (int r2 = r1 + 1; r2 < M; ++r2)
            {
                int innerSum = 0;
                if (r2 >= r1 + 2)
                {
                    // sum of a[r1+1..r2-1][j]
                    int bottomIndex = r2 - 1;
                    int topIndex = r1;
                    innerSum = colPref[bottomIndex][j] - colPref[topIndex][j];
                }
                Cell start = (Cell)(r1 * N + j);
                Cell end = (Cell)(r2 * N + j);
                Segment s;
                s.start = start;
                s.end = end;
                s.w = innerSum;
                s.dir = 1; // vertical
                segments.push_back(s);
            }
        }
    }

    // Sort segments by weight in descending order
    sort(segments.begin(), segments.end(),
         [](const Segment &a, const Segment &b)
         {
             return a.w > b.w;
         });

    // DP arrays:
    // bestH[cell] = best total valves for a path ending in 'cell' with last segment horizontal
    // bestV[cell] = same but last segment vertical
    const long long NEG = -1;
    vector<long long> bestH(cells, NEG);
    vector<long long> bestV(cells, NEG);

    long long answer = 0;
    size_t sz = segments.size();
    size_t i = 0;

    // Process segments grouped by equal weight
    while (i < sz)
    {
        size_t j = i;
        int curW = segments[i].w;

        // Find the end of this weight group [i, j)
        while (j < sz && segments[j].w == curW)
        {
            ++j;
        }

        size_t groupSize = j - i;
        // Temporary DP values for this group
        vector<long long> temp(groupSize, NEG);

        // First, compute DP for all segments in this group
        for (size_t k = 0; k < groupSize; ++k)
        {
            const Segment &s = segments[i + k];
            Cell start = s.start;
            Cell end = s.end;
            char dir = s.dir;
            int w = s.w;

            long long bestTotal = NEG;

            // Option 1: this is the first segment starting at the start cell
            if (start == startCell)
            {
                if (w > bestTotal)
                {
                    bestTotal = (long long)w;
                }
            }

            // Option 2: attach after a previous segment of opposite direction
            long long prevBest = (dir == 0 ? bestV[start] : bestH[start]);
            if (prevBest != NEG)
            {
                long long candidate = prevBest + (long long)w;
                if (candidate > bestTotal)
                {
                    bestTotal = candidate;
                }
            }

            temp[k] = bestTotal;

            // If this segment ends in the destination cell, update global answer
            if (end == destCell && bestTotal != NEG && bestTotal > answer)
            {
                answer = bestTotal;
            }
        }

        // Second, update bestH / bestV with results from this group
        for (size_t k = 0; k < groupSize; ++k)
        {
            long long val = temp[k];
            if (val == NEG)
                continue;

            const Segment &s = segments[i + k];
            Cell end = s.end;
            if (s.dir == 0)
            {
                // horizontal
                if (val > bestH[end])
                {
                    bestH[end] = val;
                }
            }
            else
            {
                // vertical
                if (val > bestV[end])
                {
                    bestV[end] = val;
                }
            }
        }

        i = j;
    }

    cout << answer << '\n';
    return 0;
}
